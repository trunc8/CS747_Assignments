## Windy Gridworld

#### Python3 Dependencies

1. numpy
2. matplotlib

#### How to Run

1. *(Optional)* Enter your python3 virtual environment.
2. `cd submission\`
3. `python3 main.py`
4. View the four plots saved into the `submission\` directory.

#### Author
```
Siddharth Saha
```